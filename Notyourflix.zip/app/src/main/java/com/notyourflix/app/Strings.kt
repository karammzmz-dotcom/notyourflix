package com.notyourflix.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf

val LocalLang = staticCompositionLocalOf { "en" }

object Strings {
    private val en = mapOf(
        "home" to "Home", "search" to "Search", "settings" to "Settings",
        "continue_watching" to "Continue Watching", "for_you" to "For You",
        "who" to "Who is watching?", "profiles" to "Profiles", "add_profile" to "Add Profile",
        "change_font" to "Change font", "change_profile" to "Change profile",
        "change_image" to "Change profile image", "change_name" to "Change profile name",
        "change_lang" to "Change language", "upload_movie" to "Upload a movie",
        "lock_add" to "Add profile lock to this profile", "lock_remove" to "Remove profile lock",
        "new_profile" to "Make a new profile", "change_sound" to "Change sound FX",
        "change_intro" to "Change intro", "change_intro_profile" to "Change intro for going in a profile",
        "delete_profile" to "Delete this profile", "movie" to "Movie", "series" to "Series",
        "title" to "Title", "description" to "Description", "cover_image" to "Cover image",
        "upload_own_image" to "Upload your own image", "video_file" to "Upload video: MP4 or WebM",
        "upload" to "Upload", "finish" to "Finish", "play" to "Play", "resume" to "Resume",
        "restart" to "Start over", "delete" to "Delete", "cancel" to "Cancel", "save" to "Save",
        "enter_pin" to "Enter PIN", "set_pin" to "Choose a 4-digit PIN", "confirm_pin" to "Confirm your PIN",
        "wrong_pin" to "Wrong PIN", "pin_mismatch" to "PINs don't match",
        "empty_title" to "Nothing here yet", "empty_sub" to "Upload your first movie",
        "no_results" to "No results", "name" to "Name", "color" to "Color",
        "gallery" to "Choose from gallery", "default_face" to "Use default face",
        "off" to "Off", "custom" to "Custom file…", "soft" to "Soft", "retro" to "Retro", "chime" to "Chime",
        "none" to "None", "zoom" to "Zoom", "glow" to "Glow",
        "font_default" to "Default", "font_sans" to "Sans Serif", "font_serif" to "Serif",
        "font_mono" to "Monospace", "font_hand" to "Handwriting",
        "episodes" to "episodes", "episode" to "Episode", "search_hint" to "Search movies and series",
        "selected" to "Selected", "fill_form" to "Add a title and choose a video", "saved" to "Saved",
        "delete_confirm" to "Delete this title?", "delete_profile_confirm" to "Delete this profile?",
        "last_profile" to "You need at least one profile", "video_type" to "Video type",
        "language" to "Language", "pause" to "Pause", "space" to "Space", "add_episodes" to "Add episodes", "kids_lock_add" to "Add kids lock", "kids_lock_remove" to "Remove kids lock", "title_logo" to "Title logo (Home banner only)", "more_info" to "More info", "cover_vertical" to "Vertical cover (poster)", "cover_horizontal" to "Horizontal cover (backdrop)", "shows" to "Shows", "movies" to "Movies", "skip_intro" to "Skip intro", "options" to "Options", "speed" to "Playback speed",
        "subtitles" to "Subtitles", "audio" to "Audio", "quality" to "Quality", "auto" to "Auto",
        "no_subs" to "No subtitles for this video", "pip" to "PiP", "edit" to "Edit", "manage_episodes" to "Episodes",
        "edit_title" to "Edit title", "change_cover" to "Change cover", "intro_label" to "Intro",
        "intro_start" to "Start (m:ss)", "intro_end" to "End (m:ss)", "add_subtitle" to "Add subtitle (.srt / .vtt)",
        "remove" to "Remove", "sub_lang" to "Subtitle language", "subtitle_files" to "Subtitles (.srt / .vtt)",
        "filter_all" to "All", "episode_title" to "Episode title", "kids" to "Kids", "kids_mode" to "Kids mode", "kids_profile" to "Kids profile",
        "on" to "On", "age_filter" to "Age filter", "no_limit" to "No limit", "locked_kids" to "Locked by kids mode",
        "manage_groups" to "Manage groups", "new_group" to "New group", "group_name" to "Group name",
        "add_to_group" to "Add to group", "genres" to "Genres", "add_genre" to "Add a genre", "age_rating" to "Age rating",
        "groups" to "Groups", "done" to "Done", "no_groups" to "No groups yet",
        "g_action" to "Action", "g_comedy" to "Comedy", "g_drama" to "Drama", "g_horror" to "Horror", "g_sci-fi" to "Sci-Fi",
        "g_romance" to "Romance", "g_documentary" to "Documentary", "g_animation" to "Animation", "g_family" to "Family",
        "g_thriller" to "Thriller", "g_fantasy" to "Fantasy", "g_adventure" to "Adventure", "my_font" to "Uploaded font", "bad_font" to "Couldn't load that font file", "next_episode" to "Next episode", "working" to "Saving…"
    )
    private val ar = mapOf(
        "home" to "الرئيسية", "search" to "بحث", "settings" to "الإعدادات",
        "continue_watching" to "متابعة المشاهدة", "for_you" to "لك",
        "who" to "من يشاهد؟", "profiles" to "الملفات الشخصية", "add_profile" to "إضافة ملف شخصي",
        "change_font" to "تغيير الخط", "change_profile" to "تغيير الملف الشخصي",
        "change_image" to "تغيير صورة الملف الشخصي", "change_name" to "تغيير اسم الملف الشخصي",
        "change_lang" to "تغيير اللغة", "upload_movie" to "رفع فيلم",
        "lock_add" to "إضافة قفل لهذا الملف الشخصي", "lock_remove" to "إزالة قفل الملف الشخصي",
        "new_profile" to "إنشاء ملف شخصي جديد", "change_sound" to "تغيير المؤثرات الصوتية",
        "change_intro" to "تغيير المقدمة", "change_intro_profile" to "تغيير المقدمة عند الدخول إلى ملف شخصي",
        "delete_profile" to "حذف هذا الملف الشخصي", "movie" to "فيلم", "series" to "مسلسل",
        "title" to "العنوان", "description" to "الوصف", "cover_image" to "صورة الغلاف",
        "upload_own_image" to "ارفع صورتك الخاصة", "video_file" to "رفع الفيديو: MP4 أو WebM",
        "upload" to "رفع", "finish" to "إنهاء", "play" to "تشغيل", "resume" to "متابعة",
        "restart" to "البدء من جديد", "delete" to "حذف", "cancel" to "إلغاء", "save" to "حفظ",
        "enter_pin" to "أدخل الرمز السري", "set_pin" to "اختر رمزاً من 4 أرقام", "confirm_pin" to "أكّد الرمز السري",
        "wrong_pin" to "الرمز غير صحيح", "pin_mismatch" to "الرمزان غير متطابقين",
        "empty_title" to "لا يوجد شيء هنا بعد", "empty_sub" to "ارفع أول فيلم لك",
        "no_results" to "لا توجد نتائج", "name" to "الاسم", "color" to "اللون",
        "gallery" to "اختيار من المعرض", "default_face" to "استخدام الوجه الافتراضي",
        "off" to "إيقاف", "custom" to "ملف مخصص…", "soft" to "ناعم", "retro" to "كلاسيكي", "chime" to "جرس",
        "none" to "بدون", "zoom" to "تكبير", "glow" to "توهج",
        "font_default" to "الافتراضي", "font_sans" to "بدون زوائد", "font_serif" to "بزوائد",
        "font_mono" to "أحادي المسافة", "font_hand" to "خط يدوي",
        "episodes" to "حلقات", "episode" to "الحلقة", "search_hint" to "ابحث عن فيلم أو مسلسل",
        "selected" to "تم الاختيار", "fill_form" to "أدخل العنوان واختر فيديو", "saved" to "تم الحفظ",
        "delete_confirm" to "حذف هذا العمل؟", "delete_profile_confirm" to "حذف هذا الملف الشخصي؟",
        "last_profile" to "يجب أن يبقى ملف شخصي واحد على الأقل", "video_type" to "نوع الفيديو",
        "language" to "اللغة", "pause" to "إيقاف مؤقت", "space" to "مسافة", "add_episodes" to "إضافة حلقات", "kids_lock_add" to "إضافة قفل الأطفال", "kids_lock_remove" to "إزالة قفل الأطفال", "title_logo" to "شعار العنوان (للافتتاحية في الرئيسية فقط)", "more_info" to "مزيد من المعلومات", "cover_vertical" to "غلاف عمودي (ملصق)", "cover_horizontal" to "غلاف أفقي (خلفية)", "shows" to "المسلسلات", "movies" to "الأفلام", "skip_intro" to "تخطي المقدمة", "options" to "خيارات", "speed" to "سرعة التشغيل",
        "subtitles" to "الترجمة", "audio" to "الصوت", "quality" to "الجودة", "auto" to "تلقائي",
        "no_subs" to "لا توجد ترجمة لهذا الفيديو", "pip" to "نافذة عائمة", "edit" to "تعديل", "manage_episodes" to "الحلقات",
        "edit_title" to "تعديل العنوان", "change_cover" to "تغيير الغلاف", "intro_label" to "المقدمة",
        "intro_start" to "البداية (د:ث)", "intro_end" to "النهاية (د:ث)", "add_subtitle" to "إضافة ترجمة (.srt / .vtt)",
        "remove" to "إزالة", "sub_lang" to "لغة الترجمة", "subtitle_files" to "الترجمة (.srt / .vtt)",
        "filter_all" to "الكل", "episode_title" to "عنوان الحلقة", "kids" to "أطفال", "kids_mode" to "وضع الأطفال", "kids_profile" to "ملف للأطفال",
        "on" to "تشغيل", "age_filter" to "فلتر العمر", "no_limit" to "بدون حد", "locked_kids" to "مقفل بسبب وضع الأطفال",
        "manage_groups" to "إدارة المجموعات", "new_group" to "مجموعة جديدة", "group_name" to "اسم المجموعة",
        "add_to_group" to "إضافة إلى مجموعة", "genres" to "الأنواع", "add_genre" to "إضافة نوع", "age_rating" to "التصنيف العمري",
        "groups" to "المجموعات", "done" to "تم", "no_groups" to "لا توجد مجموعات بعد",
        "g_action" to "أكشن", "g_comedy" to "كوميديا", "g_drama" to "دراما", "g_horror" to "رعب", "g_sci-fi" to "خيال علمي",
        "g_romance" to "رومانسي", "g_documentary" to "وثائقي", "g_animation" to "رسوم متحركة", "g_family" to "عائلي",
        "g_thriller" to "إثارة", "g_fantasy" to "فانتازيا", "g_adventure" to "مغامرة", "my_font" to "الخط المرفوع", "bad_font" to "تعذر تحميل ملف الخط", "next_episode" to "الحلقة التالية", "working" to "جارٍ الحفظ…"
    )
    fun get(lang: String, k: String): String = (if (lang == "ar") ar else en)[k] ?: en[k] ?: k
}

@Composable
fun tr(k: String): String = Strings.get(LocalLang.current, k)
